var uploadChk;
  
var map;
var uploadChk;
var allMarkers = [];

function initialize() {
   $('#clear').click(clearAllMarkers);
   $("#simulator").click(preSimulator);
   $("#ff1x").click(function(){ ff = 1;});
   $("#ff3x").click(function(){ ff = 3;});
   $("#ff10x").click(function(){ ff = 10;});
   $("#ff50x").click(function(){ ff = 50;});
   uploadChk = $('#upload');
   
   var mapCenter = new google.maps.LatLng(22.419005, 114.206904);
   var myOptions = {
     zoom: 15,
     center: mapCenter,
     mapTypeId: google.maps.MapTypeId.ROADMAP
   };
   map = new google.maps.Map($("#map_canvas").get(0), myOptions);
}
  
  var ff = 3;
  var preSimulator = function(evt){	
	locationData = locationData1;
	doSimulator(locationData);
  }
  
  var doSimulator = function(data,bar){
	var marker;
	var markersArray = [];
	var cnt = 5;
	var upload = new Uploader();
	var timestamp ;
	var doDelay = function(i){
		if(i<data.length){			
			timestamp = data[i][0];
			marker = createMarker(map,data[i]);
			bar.width(i/data.length*100 + "%");
			/****** This is the upload call, remove it to reduce server load....**/
			if(uploadChk.attr('checked'))
				upload.doUpload(data[i][1],data[i][2]);
			
			(markersArray.push(marker) > cnt && markersArray.shift().setMap(null));
			
			if(i < (data.length - 1))
				setTimeout(function(){doDelay(i+1)}, (data[i+1][0] - timestamp) / ff);
			else{
				setTimeout(function(){doDelay(i+1)},1000);
			}			
		}else{
				upload.stopUpload();
			while(markersArray.length>0){
				markersArray.shift().setMap(null);
			}
			
			markersArray = null;
			upload = null;
		}
	}	
	doDelay(0);
  };  

  function drawMarker(points){
	var markersArray = [];
  	for(i=0; i< points.length; i++){
	    marker = createMarker(map,points[i]);
		markersArray.push(marker);
	}
	allMarkers.push(markersArray);
	return markersArray;
  }
  
  function createMarker(map,data){
	var marker = new google.maps.Marker({
		    position: new google.maps.LatLng(
				data[1],data[2]),
			map: map,
			title: data[4]
		});
		google.maps.event.addListener(marker, 'click', function(){
			onClickLocation(data);
		});
	//$("#location_info").html(data[4] + "<br>" + data[1] + "," + data[2] );
	
	return marker;
  }
  
  function clearMarkers(markersArray){
	if(!markersArray) return;
	while(markersArray.length != 0)
	  markersArray.shift().setMap(null)
	markersArray = null;
  }
  
  function clearAllMarkers(){
	while(allMarkers.length!=0)
		clearMarkers(allMarkers.shift());
  }
  
  function onClickLocation(data){
	/*document.getElementById("location_name").innerHTML = data[2];
	document.getElementById("location_image").src = 
		"http://www.housingauthority.gov.hk/hdw/content/images/en/interactivemap/prh/" + data[3];*/
  }