var simsList;
var LocationDataDB = new Array();

$(document).ready(function(){
	simsList= $('#sims-list');
	
	var obtainBtn = $('#obtain');
	obtainBtn.click(function(evt){
		$id = $('#sims-file').val();
		//if(LocationDataDB[$id]) return;
		$.getJSON(
			"./data/data.php?callback=?",
			{id:$id},
			addSimsFile
		);
	});
});

function addSimsFile(data){
	if(data.data.length<=0)return;
	var dom = $('<div></div>');
	var start = $("<input type='button' value='Start'></input>");
	var id = data.id;
	var stops = data.stop;
	
	var bar = $("<div class='load'></div>");
	
	LocationDataDB[id] = data.data;
	
	start.click(function(evt){
		var sims = new simulator(LocationDataDB[id],stops,bar);
		sims.start();
	});
	var markers = [];
	var view = $("<input type='button' value='view'></input>");
	view.click(function(evt){
		clearAllMarkers();
		markers = drawMarker(LocationDataDB[id]);
	});
	
	
	dom.dataid = id;
	dom.html(data.name);
	
	dom.append(view);
	dom.append(start);
	
	var loadbar = $("<div class='bar'></div>");
	loadbar.append(bar);
	bar.width("0%");
	dom.append(loadbar);
	simsList.append(dom);
	
	data = null;
}

var simulator = function(data,stops,bar){
	
	var STOP_TIME = 0;
	var STOP_POI = 1;
	var STOP_ENTERTIME = 2;
	var STOP_LEAVETIME = 3;
	var STOP_EVENT = 4;
	
	var cache_size = 5;
	var marker;
	var markersArray = [];
	var upload = new Uploader();
	var timestamp;
	var j = 0;
	var stop = null;

	this.start = function(){
		doDelay(0);		
		if(stops.length>0)
			stop = stops[j++];
	}
	
	var doDelay = function(i){
		bar.width(i/data.length*100 + "%");
		if(i<data.length){
			var location = data[i];
			timestamp = location[0];
			/****** This is the upload call, remove it to reduce server load....**/
			if(uploadChk.attr('checked')){
				upload.doUpload(location[1],location[2]);
				if(stop!=null && stop[STOP_TIME]<timestamp){
				
					upload.uploadEvent(
						stop[STOP_POI],
						stop[STOP_ENTERTIME],
						stop[STOP_LEAVETIME],
						stop[STOP_EVENT]
					);
					if(j<stops.length){
						stop = stops[j++];
					}else{
						stop = null;
					}
				}
			}			
			
			marker = createMarker(map,location);
			(markersArray.push(marker) > cache_size && markersArray.shift().setMap(null));
			
			if(i < (data.length - 1))
				setTimeout(function(){doDelay(i+1)}, (data[i+1][0] - timestamp) / ff);
			else{
				setTimeout(function(){doDelay(i+1)},1000);
			}			
		}else{
			upload.stopUpload();
			
			while(markersArray.length>0){
				markersArray.shift().setMap(null);
			}			
			markersArray = null;
			upload = null;
		}
	}	
}