var hostname = 'http://137.189.97.174:8080';

var Uploader = function(){
	var uploadId = -1;
	this.doUpload = function(la,lo){
		if(uploadId <0){
			uploadId = Math.floor(Math.random()*100000);
			insertLocation(uploadId,la,lo);
		}else{
			updateLocation(uploadId,la,lo);	
		}
	};

	this.stopUpload = function(){
		if(uploadId!=-1)
			deleteLocation(uploadId);
		uploadId = -1;
	};

	this.uploadEvent = function(poi,t1,t2,evt){
		var url = hostname + '/servlet/FYPServer?passkey=ieakpuser&callback=?&'
		   + "cmsg=passedadd/" + uploadId + "/" + t1 + "/" + t2 + "/" + poi + "/" + evt;
		$.getJSON(url,
		uploadToServer);
	}
	
	var insertLocation = function(id,la,lo){	
	    var cuhk = new LatLon(22.419005,114.206904);
		var p2 = new LatLon(la,lo);
	
		var url = hostname + '/servlet/FYPServer?passkey=ieakpuser&callback=?&'
		   + "cmsg=add/" + id + "/" + la + "/" + lo;
		   url += "/" + cuhk.distanceTo(p2);
		$.getJSON(url,
		uploadToServer);
	};

	var updateLocation = function(id,la,lo){	
		var url = hostname + '/servlet/FYPServer?passkey=ieakpuser&callback=?&'
		   + "cmsg=update/" + id + "/" + la + "/" + lo;
		$.getJSON(url,
		uploadToServer);
	};

	var deleteLocation = function(id){	
		var url = hostname + '/servlet/FYPServer?passkey=ieakpuser&callback=?&'
			+ "cmsg=delete/" + id
		$.getJSON(url,
		uploadToServer);
	};

	var uploadToServer = function(data){
		alert('Load was performed.');
	};
}