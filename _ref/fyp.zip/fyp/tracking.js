var trackingMarkersArray = [];
var isTracking = false;
var trackingRate = 3000;
var info;

$(document).ready(function(){
	info = $('#location_info');

	var trackingBtn = $('#tracking');
	trackingBtn.click(
		function(){		
			isTracking = !isTracking;
			if(isTracking) {
				$('#track_rate').attr('disabled',true);
				trackingRate = $('#track_rate').val() * 1000;
				if(trackingRate <1000) trackingRate = 3000;
				trackingBtn.val('Stop Track'); 
				setTimeout(trackFunction, trackingRate);				
			}else {
				$('#track_rate').removeAttr('disabled');
				trackingBtn.val('Start Track');				
			}
		});
});


var trackFunction = function(){
	if(isTracking){
		$.getJSON(
			"http://137.189.97.174:8080/servlet/FYPServer?callback=?",
			{cmsg:"info",
			passkey:"ieakpuser"},
			trackingCallback
		);
		setTimeout(trackFunction, trackingRate);
	}
}


var trackingCallback = function(xhrData){

  if (trackingMarkersArray) {
    while (trackingMarkersArray.length >0) {
		var marker = trackingMarkersArray.shift();
			marker.setMap(null);
		google.maps.event.clearListeners(marker,'click');
    }
  }

  for(var i =0 ;i <xhrData.items.length; i++){
	addTrackMarker(xhrData.items[i]);
  }
}

function addTrackMarker(data){
	var marker = new google.maps.Marker({
				position : new google.maps.LatLng(
					data.latitude,data.longitude),
				map: map,
				title: "ID:" + data.bid
			});
		google.maps.event.addListener(marker, 'click', function(){
			var cmsg = "passed/" + data.bid; 
			$.getJSON(
				"http://137.189.97.174:8080/servlet/FYPServer?callback=?",
				{cmsg:cmsg,
				passkey:"ieakpuser"},
				getPassedStop
			);
			
		});
		trackingMarkersArray.push(marker);

}

var getPassedStop = function(data){
	var stops = data.items;
	var output = "";
	
	function time2string(time){
		var dt = new Date(time);
		output = dt.getFullYear()+"-"+dt.getMonth()+"-"+dt.getDate() + " " 
			+ dt.getHours() + ":" + dt.getMinutes() + ":" + dt.getSeconds();
		return output;
	}
	
	for(var i=0;i<stops.length;i++){
		var stop = stops[i];
		//output+= stop.event + " " + stop.stop + " " + stop.enterTime + " " + stop.leaveTime + "<br/>";
		
		output+= time2string(stop.enterTime) + "|" + time2string(stop.leaveTime) + "|" + stop.stop + "<br/>";
	}
	info.html(output);
}