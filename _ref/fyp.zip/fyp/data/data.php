<?php

$id = $_GET['id'];
$callback = $_GET['callback'];
$file = 'data'. $id;
$stopfile = 'data'.$id.'stop';

if($callback){
echo "$callback(";
}
echo "{id:$id,name:\"DATA$id\", data:";
echo '[';

echo @file_get_contents($file);
echo '],stop:[';
echo @file_get_contents($stopfile);

echo ']}';
if($callback){
echo ')';
};

?>

