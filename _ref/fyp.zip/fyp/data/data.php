<?php

$id = $_GET['id'];
$callback = $_GET['callback'];
$file = 'data'. $id;
$stopfile = 'data'.$id.'stop';

$name = "DATA$id";

if($id == "1") $name = "SIMS-1";
if($id == "2") $name = "SIMS-2";
if($id == "71") $name = "Processed1";
if($id == "41") $name = "MTR->NA";
if($id == "91") $name = "MTR->SRR";
if($id == "51") $name = "MTR->UC";

if($callback){
echo "$callback(";
}
echo "{id:$id,name:\"$name\", data:";
echo '[';

echo @file_get_contents($file);
echo '],stop:[';
echo @file_get_contents($stopfile);

echo ']}';
if($callback){
echo ')';
};

?>

