#!/usr/bin/perl

my $var = shift;
my $apple=1;
while(<>) {
   $regex = ".* update\/$var";
   if(/$regex/){
      if($apple==1){
         $apple=0;
      }else{
         print ",";
      }
	  ($r1,$r2,$r3,$r4) = /(.*) update\/(\d+)\/(\d+.\d+)\/(\d+.\d+)/;
	  $_ = $r1;
	  ($d1,$d2,$d3,$d4,$d5,$d6) = /(\d{4})-(\d{2})-(\d{2})-(\d{2})(\d{2})(\d{2})/;
	  	  
	  $time =  ((($d4*60) + $d5) *60 + $d6) *1000;
	  $_ = "[$time,$r3,$r4,2,\"$r1\"]\n";
      print

   }
   
   
}