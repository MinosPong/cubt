var busStopsMarkersArray = [];

var TYPE_STOP = 1;
var TYPE_CHECKPOINT = 2;
var TYPE_CUHK = 3;

var STOP_MTR = "Train Station";
var STOP_SPU = "University Sports Centre (Upward)";
var STOP_SPD = "University Sports Centre (Downward)";
var STOP_SRR = "Sir Run Run Hall";
var STOP_FKH = "Fung King Hey Building";
var STOP_UCS = "United college";
var STOP_NAS = "New Asia College";
var STOP_ADM = "University Administrative Building";
var STOP_P5H = "Pentecostal Mission Hall Complex";
var STOP_R34 = "Residences No.3 and 4";
var STOP_SCS = "Shaw College";
var STOP_R11 = "Residences No.10 and 11";
var STOP_R15 = "Residences No.15";
var STOP_RUC = "United College Staff Residence";
var STOP_CCH = "Chan Chun Ha Hostel";
var STOP_PGH = "Jockey Club Post-Graduate Hall";
var STOP_CCS = "Chung Chi Teaching Blocks";
	//checkpoints
var CHECKPOINT_CJC = "Jockey Club Post-Graduate Hall Checkpoint";
var CHECKPOINT_CCC = "Chung Chi Teaching Blocks Checkpoint";
var CHECKPOINT_CAB = "University Administrative Building Checkpoint";
var CHECKPOINT_CNA = "New Asia College Checkpoint";
var CHECKPOINT_CSC = "Shaw College Checkpoint";

var CUHK_CUHK = "CUHK";

var busData = [
[STOP_MTR, 22.414670, 114.210292, 50, TYPE_STOP],
[STOP_SPU, 22.417830, 114.210280, 30, TYPE_STOP],
[STOP_SPD, 22.417773, 114.211350, 30, TYPE_STOP],
[STOP_SRR, 22.419830, 114.207024, 50, TYPE_STOP],
[STOP_FKH, 22.419860, 114.203270, 50, TYPE_STOP],
[STOP_UCS, 22.420363, 114.205180, 50, TYPE_STOP],
[STOP_NAS, 22.421279, 114.207486, 50, TYPE_STOP],
[STOP_ADM, 22.418780, 114.205260, 50, TYPE_STOP],
[STOP_P5H, 22.418520, 114.208750, 30, TYPE_STOP],
[STOP_R34, 22.421340, 114.203450, 30, TYPE_STOP],
[STOP_SCS, 22.422397, 114.201395, 50, TYPE_STOP],
[STOP_R11, 22.425152, 114.207891, 30, TYPE_STOP],
[STOP_R15, 22.423766, 114.206700, 30, TYPE_STOP],
[STOP_RUC, 22.423364, 114.205308, 30, TYPE_STOP],
[STOP_CCH, 22.421850, 114.204600, 30, TYPE_STOP],
[STOP_PGH, 22.420360, 114.212200, 40, TYPE_STOP],
[STOP_CCS, 22.415541, 114.208218, 50, TYPE_STOP],
			//Checkpoints
[CHECKPOINT_CJC, 22.417852, 114.212770, 50, TYPE_CHECKPOINT],
[CHECKPOINT_CCC, 22.416067, 114.210625, 50, TYPE_CHECKPOINT],
[CHECKPOINT_CAB, 22.419779, 114.204453, 50, TYPE_CHECKPOINT],
[CHECKPOINT_CNA, 22.420037, 114.206287, 50, TYPE_CHECKPOINT],
[CHECKPOINT_CSC, 22.421792, 114.203315, 50, TYPE_CHECKPOINT],

[CUHK_CUHK,22.419005,114.206904,TYPE_CUHK]
];


$(document).ready(function(){
	$('#showBusStop').click(function() {
		if($('#showBusStop').attr('checked')){
			showOverlays();
		}else{
			clearOverlays();
		}
	});
});


function loadBusStopData(){
	var image = './img/stop3d.png';
	for(var i in busData){
		var data = busData[i];
		if(data[4] != TYPE_STOP) continue;
		var marker = new google.maps.Marker({
				position : new google.maps.LatLng(
					data[1],data[2]),
				map: map,
				title: data[0],
				icon: image
			});
		busStopsMarkersArray.push(marker);
	}
}

// Removes the overlays from the map, but keeps them in the array
function clearOverlays() {
  if (busStopsMarkersArray) {
    for (i in busStopsMarkersArray) {
      busStopsMarkersArray[i].setMap(null);
    }
  }
}

// Shows any overlays currently in the array
function showOverlays() {
  if(busStopsMarkersArray.length == 0) loadBusStopData();
  if (busStopsMarkersArray) {
    for (i in busStopsMarkersArray) {
      busStopsMarkersArray[i].setMap(map);
    }
  }
}